package com.example.CRUD.controller;

import com.example.CRUD.service.MovieService;
import com.example.CRUD.service.ShowtimeService;
import com.example.CRUD.service.UserService;
import com.example.mo.Movie;
import com.example.mo.Showtime;
import com.example.mo.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/movie")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private ShowtimeService showtimeService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String getAllMovies(Model model, Principal principal) {
        Integer cinemaOwnerID = getCinemaOwnerIDFromPrincipal(principal);
        List<Movie> movies = movieService.getAllMoviesByCinemaOwnerID(cinemaOwnerID);
        model.addAttribute("movies", movies);
        return "movie";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("movie", new Movie());
        return "movie-form";
    }

    @PostMapping("/create")
    public String createMovie(@ModelAttribute Movie movie, @RequestParam("imageFile") MultipartFile imageFile,
                              RedirectAttributes redirectAttributes, Principal principal) {
        movie.setRatingCount(0);
        movie.setAverageRating(0.0);

        // Set cinemaOwnerID from Principal
        movie.setCinemaOwnerID(getCinemaOwnerIDFromPrincipal(principal));

        if (!imageFile.isEmpty()) {
            try {
                // Save uploaded file to local directory
                String uploadDir = System.getProperty("user.dir") + "/uploads/";
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) {
                    uploadDirFile.mkdirs();
                }
                String fileName = imageFile.getOriginalFilename();
                Path filePath = Paths.get(uploadDir + fileName);
                Files.write(filePath, imageFile.getBytes());
                movie.setAddress("/uploads/"+ fileName); // Save image path to address attribute
            } catch (IOException e) {
                e.printStackTrace();
                redirectAttributes.addFlashAttribute("message", "Cannot upload image file.");
                return "redirect:/movie/new";
            }
        }
        movieService.saveMovie(movie);
        return "redirect:/movie";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Movie movie = movieService.getMovieById(id);
        if (movie != null) {
            model.addAttribute("movie", movie);
            return "movie-form";
        }
        return "redirect:/movie";
    }

    @PostMapping("/update/{id}")
    public String updateMovie(@PathVariable Integer id, @ModelAttribute Movie movieDetails,
                              @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                              RedirectAttributes redirectAttributes) {
        Movie movie = movieService.getMovieById(id);
        if (movie != null) {
            if (imageFile != null && !imageFile.isEmpty()) {
                try {
                    // Save uploaded file to local directory
                    String uploadDir = System.getProperty("user.dir") + "/uploads/";
                    File uploadDirFile = new File(uploadDir);
                    if (!uploadDirFile.exists()) {
                        uploadDirFile.mkdirs();
                    }
                    String fileName = imageFile.getOriginalFilename();
                    Path filePath = Paths.get(uploadDir + fileName);
                    Files.write(filePath, imageFile.getBytes());
                    movie.setAddress("/uploads/" + fileName); // Save image path to address attribute
                } catch (IOException e) {
                    e.printStackTrace();
                    redirectAttributes.addFlashAttribute("message", "Cannot upload image file.");
                    return "redirect:/movie/edit/" + id;
                }
            }
            movie.updateDetails(movieDetails);
            movieService.saveMovie(movie);
        }
        return "redirect:/movie";
    }

    @GetMapping("/delete/{id}")
    public String deleteMovie(@PathVariable Integer id) {
        movieService.deleteMovie(id);
        return "redirect:/movie";
    }

    @GetMapping("/home/{id}")
    public String getMovieForHome(@PathVariable Integer id, Model model) {
        Movie movie = movieService.getMovieById(id);
        if (movie != null) {
            model.addAttribute("movie", movie);
            return "home";
        }
        return "redirect:/movie";
    }

    @GetMapping("/home")
    public String getAllMoviesForHome(Model model) {
        List<Movie> movies = movieService.getAllMovies();
        List<Movie> simplifiedMovies = movies.stream()
                .map(m -> {
                    Movie simplifiedMovie = new Movie();
                    simplifiedMovie.setTitle(m.getTitle());
                    simplifiedMovie.setGenre(m.getGenre());
                    simplifiedMovie.setAddress(m.getAddress());
                    return simplifiedMovie;
                })
                .collect(Collectors.toList());
        model.addAttribute("movies", simplifiedMovies);
        return "home";
    }

    @GetMapping("/book/{id}")
public String showMovieDetails(@PathVariable("id") Integer id, Model model, Principal principal) {
    Movie movie = movieService.getMovieById(id);

    if (movie != null && principal != null) {
        String email = principal.getName();
        Users user = userService.getUsersByEmail(email);
        
        model.addAttribute("user", user);
        model.addAttribute("movie", movie);
        return "book"; // Tên của trang HTML cho chi tiết phim
    }
    return "redirect:/movie";
}

    private Integer getCinemaOwnerIDFromPrincipal(Principal principal) {
        Users user = userService.getUsersByEmail(principal.getName());
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        return user.getUserId(); // Ensure this returns the correct ID for cinema owner
    }
}
