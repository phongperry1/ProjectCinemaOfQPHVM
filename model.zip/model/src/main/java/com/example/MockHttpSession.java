package com.example;

public class MockHttpSession {

}
