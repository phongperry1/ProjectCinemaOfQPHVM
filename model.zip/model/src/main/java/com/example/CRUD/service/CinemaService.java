package com.example.CRUD.service;

public interface CinemaService {
    
}