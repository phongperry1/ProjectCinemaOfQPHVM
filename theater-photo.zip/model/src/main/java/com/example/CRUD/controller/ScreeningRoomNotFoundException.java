package com.example.CRUD.controller;

public class ScreeningRoomNotFoundException extends Throwable {
    public ScreeningRoomNotFoundException(String message) {
        super(message);
    }
}