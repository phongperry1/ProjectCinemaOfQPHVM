package com.example.CRUD.controller;
public class PromotionsNotFoundException extends Throwable {
    public PromotionsNotFoundException(String message) {
        super(message);
    }
}