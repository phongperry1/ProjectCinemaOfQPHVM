package com.example;

public class PriceTest {
    public PriceTest() {
        // TODO Auto-generated method stub
    }
}